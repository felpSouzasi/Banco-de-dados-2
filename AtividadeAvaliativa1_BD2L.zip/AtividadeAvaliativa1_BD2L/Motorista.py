class Motorista:
    def __init__(self, corridas=[], nota=0):
        self.corridas = corridas
        self.nota = nota