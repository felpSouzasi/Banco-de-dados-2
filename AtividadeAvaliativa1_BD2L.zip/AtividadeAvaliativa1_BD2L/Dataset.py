{
    "motoristas": [
        {
            "corridas": [
                {
                    "nota": 4,
                    "distancia": 10.5,
                    "valor": 25.0,
                    "passageiro": {
                        "nome": "João da Silva",
                        "documento": "123456789"
                    }
                },
                {
                    "nota": 5,
                    "distancia": 8.2,
                    "valor": 20.0,
                    "passageiro": {
                        "nome": "Maria Oliveira",
                        "documento": "987654321"
                    }
                }
            ],
            "nota": 4
        },
        {
            "corridas": [
                {
                    "nota": 3,
                    "distancia": 15.3,
                    "valor": 30.0,
                    "passageiro": {
                        "nome": "José Santos",
                        "documento": "456123789"
                    }
                }
            ],
            "nota": 3
        }
    ]
}
