from database import Database
from helper.writeAJson import writeAJson

class Pokedex:
    pass

class Database:
    def __init__(self, pokedex: Pokedex):
        _pokedex = Pokedex

    def query1(self):
        fraquezas = ["Psychic", "Ice"]
        pokemons = db.collection.find({"weaknesses": {"$all": fraquezas}})
        writeAJson(pokemons, "pokemons")
        return pokemons

    def query2(self):
        pokemons = db.collection.find({"weaknesses": {"$size": 1}})
        writeAJson(pokemons, "pokemons")
        return pokemons

    def query3(self):
        pokemons = db.collection.find({"spawn_chance": {"$gt": 0.3, "$lt": 0.6}})
        writeAJson(pokemons, "pokemons")
        return pokemons

    def query4(self):
        pokemons = db.collection.find({"next_evolution.1.num": {"$lte": "020"}})
        writeAJson(pokemons, "pokemons")
        return pokemons

    def query5(self):
        tipos = ["Grass", "Poison"]
        pokemons = db.collection.find({"type": {"$in": tipos}, "next_evolution": {"$exists": True}})
        writeAJson(pokemons, "pokemons")
        return pokemons


if __name__ == "__main__":
    db = Database("dataset")
    pokedex = Pokedex(db)
    pokedex.query1()
    pokedex.query2()
    pokedex.query3()
    pokedex.query4()
    pokedex.query5()
